#include<iostream>
#include<thread>
#include<ctime>
#include<cstdlib>
#include<mutex>

using namespace std;

bool finish[5] = { false };
mutex mutex_lock;

void printState(int arr1[][3], int arr2[][3], int arr3[][3], int arr4[])
{
	cout << "Available [ " << arr4[0] << " " << arr4[1] << " " << arr4[2] << " ]" << endl;
	cout << "\t\tALLOCATED \tMAXIMUM \tNEED" << endl;
	for (int i = 0; i < 5; i++)
	{
		cout << "\t\t[ ";
		if (finish[i] == true)
		{
			cout << "----- ";
		}
		else
		{
			for (int j = 0; j < 3; j++)
			{
				cout << arr1[i][j] << " ";
			}
		}
		cout << "]\t[ ";
		if (finish[i] == true)
		{
			cout << "----- ";
		}
		else
		{
			for (int k = 0; k < 3; k++)
			{
				cout << arr2[i][k] << " ";
			}
		}
		cout << "]\t[ ";
		if (finish[i] == true)
		{
			cout << "----- ";
		}
		else
		{
			for (int l = 0; l < 3; l++)
			{
				cout << arr3[i][l] << " ";
			}
		}
		cout << "]" << endl;
	}
	cout << endl;
}

void calcNeed(int arr1[][3], int arr2[][3], int arr3[][3])
{
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			arr3[i][j] = arr2[i][j] - arr1[i][j];
		}
	}
}

void prompt()
{
	cout << "Enter * to get the state of the system, OR Enter: <Thread ID> <resource #0> <#1> <#2>" << endl;
}

bool isFree(int id, int alloc[][3], int need [][3], int avail[])
{
	if ((need[id][0] == 0) && (need[id][1] == 0) && (need[id][2] == 0) && (finish[id] == false))
	{
		avail[0] += alloc[id][0];
		avail[1] += alloc[id][1];
		avail[2] += alloc[id][2];
		finish[id] = true;
		return true;
	}
	else
		return false;
}


void request(int id, int R1, int R2, int R3, int alloc[][3], int max [][3], int need[][3], int avail[])
{
	mutex_lock.lock();
	cout << "Process " << id << " requesting [ " << R1 << " " << R2 << " " << R3 << " ] ";
	if (finish[id] == true)
	{
		cout << "Process already terminated!" << endl;
		mutex_lock.unlock();
		return;
	}
	if ((need[id][0] - R1 >= 0 && alloc[id][0] + R1 <= max[id][0]) && (need[id][1] - R2 >= 0 && alloc[id][1] + R2 <= max[id][1])
		&& (need[id][2] - R3 >= 0 && alloc[id][2] + R3 <= max[id][2]) && (avail[0] - R1 >= 0 && avail[1] - R2 >= 0 && avail[2] - R3 >= 0))
	{
		need[id][0] -= R1; //update need matrix
		alloc[id][0] += R1; //update allocation matrix
		need[id][1] -= R2;
		alloc[id][1] += R2;
		need[id][2] -= R3;
		alloc[id][2] += R3;

		avail[0] -= R1; //update available matrix
		avail[1] -= R2;
		avail[2] -= R3;
		cout << "Process " << id << " now at [ " << alloc[id][0] << " " << alloc[id][1] << " " << alloc[id][2] << " ] " << endl;

		if (isFree(id, alloc, need, avail))
		{
			cout << "Process " << id << " has all its resources! Releasing all resources and SHUTTING DOWN" << endl;
		}
		printState(alloc, max, need, avail);
		mutex_lock.unlock();
		return;
	}
	else
	{
		cout << "Request Denied\n";
		mutex_lock.unlock();
		return;
	}
}

int main()
{
	char userInput, modeSelect;
	int threadID, rOne, rTwo, rThree;

	int allocMatrix[5][3] = { { 3, 2, 1 },{ 2, 0, 0 },{ 3, 0, 2 },{ 2, 1,1 },{ 0, 0, 2 } };
	int maxMatrix[5][3] = { { 7, 5, 3 },{ 3, 2, 2 },{ 9, 0, 2 },{ 2, 2, 2 },{ 4, 3, 3 } };
	int needMatrix[5][3];
	int available[3] = { 10, 5, 7 };

	calcNeed(allocMatrix, maxMatrix, needMatrix);
	printState(allocMatrix, maxMatrix, needMatrix, available);

	int rand1, rand2, rand3;
	srand(time(NULL));
	
	cout << "Please select a mode (a- automatic OR i-interactive): ";
	cin >> modeSelect;

	if (modeSelect == 'a')  //automatic mode
	{
		while ((finish[0] && finish[1] && finish[2] && finish[3] && finish[4]) == false)
		{
			if (finish[0] == false)
			{
				rand1 = rand() % 4;
				rand2 = rand() % 3;
				rand3 = rand() % 3;
				thread t0(request, 0, rand1, rand2, rand3, allocMatrix, maxMatrix, needMatrix, available);
				t0.join();
			}

			if (finish[1] == false)
			{
				rand1 = rand() % 4;
				rand2 = rand() % 3;
				rand3 = rand() % 3;
				thread t1(request, 1, rand1, rand2, rand3, allocMatrix, maxMatrix, needMatrix, available);
				t1.join();
			}
			if (finish[2] == false)
			{
				rand1 = rand() % 4;
				rand2 = rand() % 3;
				rand3 = rand() % 3;
				thread t2(request, 2, rand1, rand2, rand3, allocMatrix, maxMatrix, needMatrix, available);
				t2.join();
			}
			if (finish[3] == false)
			{
				rand1 = rand() % 4;
				rand2 = rand() % 3;
				rand3 = rand() % 3;
				thread t3(request, 3, rand1, rand2, rand3, allocMatrix, maxMatrix, needMatrix, available);
				t3.join();
			}
			if (finish[4] == false)
			{
				rand1 = rand() % 4;
				rand2 = rand() % 3;
				rand3 = rand() % 3;
				thread t4(request, 4, rand1, rand2, rand3, allocMatrix, maxMatrix, needMatrix, available);
				t4.join();
			}
		}
	}

	if (modeSelect == 'i') //interactive mode
	{
		do {
			prompt();
			cin >> userInput;
			if (userInput == '*')
			{
				printState(allocMatrix, maxMatrix, needMatrix, available);
			}
			else
			{
				cin >> rOne >> rTwo >> rThree;
				threadID = userInput - 48; //convert char to int
				thread userThread(request, threadID, rOne, rTwo, rThree, allocMatrix, maxMatrix, needMatrix, available);
				userThread.join();
			}
		} while ((finish[0] && finish[1] && finish[2] && finish[3] && finish[4]) == false);
	}
	
	cout << "*****All resources have been released*****" << endl;

	system("pause");
	return 0;
}